import { useMemo, useState } from "react";
import { TonConnectButton, useTonAddress, useTonConnectUI } from "@tonconnect/ui-react";
import { Address } from "@ton/core";

type Screen = "home" | "wallet" | "withdraw" | "review" | "result";

const API = import.meta.env.VITE_API_URL || "http://localhost:3001";

function shortAddress(address: string) {
  return address ? `${address.slice(0, 6)}...${address.slice(-4)}` : "";
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [amount, setAmount] = useState("");
  const [destination, setDestination] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState("");
  const [tonConnectUI] = useTonConnectUI();
  const address = useTonAddress(true);
  const userFriendlyAddress = useTonAddress(false);

  const validDestination = useMemo(() => {
    try {
      if (!destination) return false;
      Address.parse(destination);
      return true;
    } catch {
      return false;
    }
  }, [destination]);

  async function refreshWallet() {
    setBusy(true);
    try {
      // Hook for your backend balance endpoint.
      await fetch(`${API}/api/wallet/${encodeURIComponent(userFriendlyAddress || address)}`);
    } finally {
      setBusy(false);
    }
  }

  async function approveWithdraw() {
    if (!userFriendlyAddress || !validDestination || Number(amount) <= 0) return;
    setBusy(true);
    setResult("");
    try {
      const r = await fetch(`${API}/api/withdraw/prepare`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          from: userFriendlyAddress,
          destination,
          amount
        })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Unable to prepare withdrawal");

      // IMPORTANT: the backend must return a fully validated TON Connect transaction.
      // The frontend only asks the user's wallet to approve it; it never sees a private key.
      await tonConnectUI.sendTransaction(data.transaction);
      setResult("Transaction submitted. Wait for blockchain confirmation.");
      setScreen("result");
    } catch (e: any) {
      setResult(e?.message || "Transaction cancelled or failed.");
      setScreen("result");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="app">
      <header className="topbar">
        <img src="/tickminebot-logo.png" className="logo" />
        <div>
          <div className="brand">TICKMINE<span>BOT</span></div>
          <div className="sub">TON MINING MINI APP</div>
        </div>
      </header>

      {screen === "home" && (
        <section>
          <div className="card hero">
            <div className="eyebrow">⛏️ MINING</div>
            <div className="big-number">12,450 <small>TICK</small></div>
            <div className="muted">Mining balance · off-chain</div>
            <button className="primary" onClick={() => setScreen("withdraw")}>💸 WITHDRAW TICK</button>
          </div>
          <div className="grid">
            <button className="card action" onClick={() => setScreen("wallet")}>👛<b>MY WALLET</b><span>Connect & manage</span></button>
            <div className="card action">⛏️<b>MINING</b><span>Active</span></div>
          </div>
        </section>
      )}

      {screen === "wallet" && (
        <section>
          <div className="card">
            <h2>👛 MY WALLET</h2>
            {address ? (
              <>
                <div className="status">🟢 Connected</div>
                <p className="label">Network</p><p>TON Mainnet</p>
                <p className="label">Address</p><p className="mono">{shortAddress(userFriendlyAddress || address)}</p>
                <div className="balance-row"><span>TICK Balance</span><b>12,450 TICK</b></div>
                <div className="balance-row"><span>TON Balance</span><b>— TON</b></div>
                <button className="primary" onClick={() => setScreen("withdraw")}>💸 SEND TICK</button>
                <button className="secondary" onClick={refreshWallet} disabled={busy}>🔄 REFRESH</button>
                <button className="danger" onClick={() => tonConnectUI.disconnect()}>🔌 DISCONNECT</button>
              </>
            ) : (
              <>
                <p>Connect your TON wallet to receive and withdraw TICK.</p>
                <div className="network">Network · TON Mainnet</div>
                <p className="security">🔐 Your private key never leaves your wallet.</p>
                <TonConnectButton />
              </>
            )}
          </div>
          <button className="back" onClick={() => setScreen("home")}>← Back</button>
        </section>
      )}

      {screen === "withdraw" && (
        <section>
          <div className="card">
            <h2>💸 WITHDRAW TICK</h2>
            <div className="available">Available: <b>12,450 TICK</b></div>
            <label>Amount</label>
            <input value={amount} onChange={e => setAmount(e.target.value)} inputMode="decimal" placeholder="5,000" />
            <label>Destination</label>
            <input value={destination} onChange={e => setDestination(e.target.value)} placeholder="UQ..." />
            {destination && !validDestination && <div className="error">Invalid TON address.</div>}
            <button className="primary" disabled={!address || !validDestination || Number(amount) <= 0} onClick={() => setScreen("review")}>CONTINUE</button>
          </div>
          <button className="back" onClick={() => setScreen("home")}>← Back</button>
        </section>
      )}

      {screen === "review" && (
        <section>
          <div className="card">
            <h2>🔎 REVIEW TRANSACTION</h2>
            <div className="review"><span>Asset</span><b>TICK</b></div>
            <div className="review"><span>Amount</span><b>{amount} TICK</b></div>
            <div className="review"><span>To</span><b className="mono">{shortAddress(destination)}</b></div>
            <div className="review"><span>Network</span><b>TON Mainnet</b></div>
            <div className="warning">Only approve the transaction if the destination and amount are correct.</div>
            <div className="buttons">
              <button className="secondary" onClick={() => setScreen("withdraw")}>CANCEL</button>
              <button className="primary" disabled={busy} onClick={approveWithdraw}>{busy ? "WAITING..." : "APPROVE"}</button>
            </div>
          </div>
        </section>
      )}

      {screen === "result" && (
        <section>
          <div className="card center">
            <div className="result-icon">✓</div>
            <h2>TRANSACTION STATUS</h2>
            <p>{result}</p>
            <button className="primary" onClick={() => setScreen("home")}>BACK TO HOME</button>
          </div>
        </section>
      )}
    </main>
  );
}