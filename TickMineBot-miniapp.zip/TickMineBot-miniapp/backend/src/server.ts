import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "node:crypto";
import { Address } from "@ton/core";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT || 3001);
const MAINNET = "-239";

function validAddress(value: string) {
  try { Address.parse(value); return true; } catch { return false; }
}

// Production note: validate Telegram Mini App initData with TELEGRAM_BOT_TOKEN
// before trusting telegram_id or any user identity sent by the client.
function verifyTelegramInitData(initData: string) {
  if (!initData) return false;
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) return false;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return false;
  params.delete("hash");
  const dataCheckString = [...params.entries()].sort(([a],[b]) => a.localeCompare(b))
    .map(([k,v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const calculated = crypto.createHmac("sha256", secret).update(dataCheckString).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(calculated), Buffer.from(hash));
}

app.get("/health", (_req,res)=>res.json({ok:true, network:"TON Mainnet", chain:MAINNET}));

app.get("/api/wallet/:address", (req,res)=>{
  const address = req.params.address;
  if (!validAddress(address)) return res.status(400).json({error:"Invalid TON address"});
  res.json({address, network:"TON Mainnet", chain:MAINNET});
});

app.post("/api/withdraw/prepare", (req,res)=>{
  const {from,destination,amount} = req.body || {};
  if (!validAddress(from) || !validAddress(destination))
    return res.status(400).json({error:"Invalid TON address"});
  if (Number(amount) <= 0 || !Number.isFinite(Number(amount)))
    return res.status(400).json({error:"Invalid amount"});
  if (!process.env.TICK_JETTON_MASTER || process.env.TICK_JETTON_MASTER.startsWith("PUT_"))
    return res.status(503).json({error:"TICK_JETTON_MASTER is not configured yet"});

  // IMPORTANT:
  // This endpoint is deliberately not fabricating a Jetton transfer.
  // Once the real TICK Jetton master is supplied, implement:
  // 1) load/verify user's off-chain mining balance
  // 2) create a one-time withdrawal record
  // 3) derive the correct TICK Jetton wallet/message
  // 4) return a TON Connect transaction object
  // 5) verify the resulting on-chain transaction before marking the withdrawal confirmed.
  //
  // Never put a private key/seed phrase in this backend.
  return res.status(501).json({
    error:"TICK Jetton transfer builder is waiting for the real TICK Jetton master contract address."
  });
});

app.listen(PORT,()=>console.log(`TickMineBot API listening on ${PORT}`));